package adapters;

public class StatementAdapter {

    class ViewHolder{

    }
}
