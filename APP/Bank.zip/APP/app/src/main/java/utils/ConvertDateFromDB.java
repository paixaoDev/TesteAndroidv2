package utils;

//Faz a conversão da data recebida via get
public class ConvertDateFromDB {

    public String convert (String DBdate){
        return "";
    }
}
