package utils;

//Formata um valor recebido por get em uma agencia
public class FormatToAgency {

    public static String convert (String agency){
        return "";
    }

    public static String convert (int agency){
        return "";
    }

    public static String unconvert (String agency){
        return "";
    }
}
