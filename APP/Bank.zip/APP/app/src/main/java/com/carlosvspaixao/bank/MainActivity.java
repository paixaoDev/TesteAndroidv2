package com.carlosvspaixao.bank;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import data.UserAccount;
import utils.ConvertFloatToCurrency;

public class MainActivity extends AppCompatActivity {

    UserAccount user; //Usuario gerado ao entrar se logar

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }


}